package at.mabs.config;
/**
 * just a flag to day... don't show
 * @author bob
 *
 */
public class SilentException extends RuntimeException {

}
